// General Data
const data = [
    {
        id: 1,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Wooden Computer Table W-CT-1',
        body: 'P2,000',
        link: 'item.html',
        price: '99.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['image/item/W-CT-1/1.jpg', 'image/item/W-CT-1/2.jpg', 'image/item/W-CT-1/3.jpg' ],
        category: 'Furniture'
    },
    {
        id: 2,
        imgSrc: 'image/item/ot-1.jpg',
        header: 'Corner Desk Office Table OT-1',
        body: 'P3,000',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 3,
        imgSrc: 'image/item/dr-1.jpg',
        header: 'Wooden Dresser DR-1',
        body: 'P1,800',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/dr-1.jpg', 'image/item/DR-1/1.jpg', 'image/item/DR-1/2.jpg', 'image/item/DR-1/3.jpg', 'image/item/DR-1/4.jpg', 'image/item/DR-1/5.jpg', 'image/item/DR-1/6.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 4,
        imgSrc: 'image/item/s-1.jpg',
        header: 'Cabinet Shoe Rack CS-1',
        body: 'P2,499',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/s-1.jpg', 'image/item/s-1/1.jpg', 'image/item/s-1/2.jpg', 'image/item/s-1/3.jpg'],
        variations: ['image/item/s-1/var/1.jpg', 'image/item/s-1/var/2.jpg'],
        category: 'Furniture'
    },
    {
        id: 5,
        imgSrc: 'image/item/nt-1.jpg',
        header: 'Night Table NT-1',
        body: 'P1,499',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        variations: ['image/item/nt-1/1.jpg', 'image/item/nt-1/var/2.jpg'],
        carItm: ['image/item/nt-1.jpg', 'image/item/nt-1/1.jpg', 'image/item/nt-1/2.jpg', 'image/item/nt-1/3.jpg', 'image/item/nt-1/4.jpg' , 'image/item/nt-1/5.jpg'],
        category: 'Furniture'
    },
    {
        id: 6,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 7,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 8,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 9,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 10,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 11,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 12,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 13,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 14,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },
    {
        id: 15,
        imgSrc: 'image/item/W-CT-1.jpg',
        header: 'Office Desk',
        body: 'P',
        link: 'item.html',
        price: '199.99',
        details: 'A modern chair that combines comfort and style, perfect for any home or office.',
        carItm: ['image/item/W-CT-1.jpg', 'image/item/W-CT-1.2.jpg', 'image/item/W-CT-1.3.jpg'],
        variations: ['place2.jpg', 'place2.jpg', 'place2.jpg'],
        category: 'Furniture'
    },

    // Add more items as needed
];

// Function to render cards
function renderCards(cards) {
    const cardContainer = document.getElementById('item-cards');
    cardContainer.innerHTML = ''; // Clear previous content

    cards.forEach(card => {
        const cardElement = document.createElement('a');
        cardElement.className = 'card p-crd';
        cardElement.href = card.link; // Set the href attribute to the link
        cardElement.setAttribute('data-id', card.id); // Set data-id attribute
        cardElement.innerHTML = `
            <img src="${card.imgSrc}" class="card-img-top" alt="${card.header}">
            <div class="header">${card.header}</div>
            <div class="body">${card.body}</div>
        `;
        cardContainer.appendChild(cardElement);

        cardElement.addEventListener('click', () => {
            localStorage.setItem('selectedItem', JSON.stringify(card));
        });
    });
}

// Function to handle search action
function handleSearch() {
    const searchTerm = document.getElementById('search').value.toLowerCase();
    const filteredCards = data.filter(card =>
        card.header.toLowerCase().includes(searchTerm) ||
        card.body.toLowerCase().includes(searchTerm)
    );
    renderCards(filteredCards);
}

// Attach event listener to search button
document.getElementById('search-btn').addEventListener('click', handleSearch);

// Initial render of all cards
renderCards(data);
