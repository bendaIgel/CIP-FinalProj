document.addEventListener('DOMContentLoaded', () => {
    const selectedItem = JSON.parse(localStorage.getItem('selectedItem'));

    if (!selectedItem) {
        // Handle the case where no item is selected
        document.body.innerHTML = '<p>No item selected.</p>';
        return;
    }

    // Populate the carousel
    const carouselInner = document.querySelector('.carousel-inner');
    selectedItem.carItm.forEach((imgSrc, index) => {
        const item = document.createElement('div');
        item.className = 'carousel-item'  + (index === 0 ? ' active' : '');
        item.innerHTML = `<img src="${imgSrc}" style="" class=" mar-l m-itm-h " alt="${imgSrc}">`;
        carouselInner.appendChild(item);
    });

    // Populate the item name and price
    document.querySelector('.itm-nm').textContent = selectedItem.header;
    document.querySelector('.itm-prc').textContent = `$${selectedItem.price}`;

    // Populate the variations
    const variationsContainer = document.querySelector('.row-cols-4');
    selectedItem.variations.forEach(imgSrc => {
        const col = document.createElement('div');
        col.className = 'col';
        col.innerHTML = `
            <div class="card h-100">
                <img src="${imgSrc}" class="card-img-top" alt="${imgSrc}">
            </div>
        `;
        variationsContainer.appendChild(col);
    });

    // Populate the item details
    document.querySelector('.des').textContent = selectedItem.details;

    // Render suggestions
    renderSuggestions(selectedItem.category);
});

// Function to render suggestions
function renderSuggestions(category) {
    const suggestionsContainer = document.getElementById('suggestions-container');
    suggestionsContainer.innerHTML = ''; // Clear previous content

    const categoryItems = data.filter(item => item.category === category);
    categoryItems.forEach(item => {
        const card = `
            <div class="col">
                <div class="card h-100">
                    <img src="${item.imgSrc}" class="card-img-top" alt="${item.header}">
                    <div class="head">${item.header}</div>
                    <div class="body">${item.body}</div>
                </div>
            </div>
        `;
        suggestionsContainer.insertAdjacentHTML('beforeend', card);
    });
}

// Perform search if search term is present in URL
const searchTerm = getQueryParameter('search');
if (searchTerm) {
    document.getElementById('search').value = searchTerm; // Set search input value
    handleSearch(); // Perform search
}
